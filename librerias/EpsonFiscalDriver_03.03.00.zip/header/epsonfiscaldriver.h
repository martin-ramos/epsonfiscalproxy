/*=============================================================================
**  EPSON_FISCAL_DRIVER.H                               Epson Latin America
**=============================================================================
**  Exportable DLL functions
**===========================================================================*/
#ifndef _EPSON_FISCAL_DRIVER_H_
#define _EPSON_FISCAL_DRIVER_H_ 

/*  Constant area */
#ifdef _WIN32
  #ifdef _USRDLL
    #define DLL_EXPORT_IMPORT __declspec(dllexport)
  #else
    #ifdef __cplusplus
      #define DLL_EXPORT_IMPORT extern "C"
    #else
      #define DLL_EXPORT_IMPORT
    #endif
  #endif
  #define DLL_STD_CALL  __stdcall
#else
  #ifdef __cplusplus
    #define DLL_EXPORT_IMPORT extern "C"
    #define DLL_STD_CALL
  #else
    #define DLL_EXPORT_IMPORT
    #define DLL_STD_CALL
  #endif
#endif

DLL_EXPORT_IMPORT void  DLL_STD_CALL GetAPIVersion( char *output_buffer );

DLL_EXPORT_IMPORT void  DLL_STD_CALL SetMultiPrinter( void );

DLL_EXPORT_IMPORT void  DLL_STD_CALL setComPort( int portnumber );
DLL_EXPORT_IMPORT int   DLL_STD_CALL getComPort( void );

DLL_EXPORT_IMPORT void  DLL_STD_CALL setBaudRate( int baud  );
DLL_EXPORT_IMPORT int   DLL_STD_CALL getBaudRate( void );

DLL_EXPORT_IMPORT void  DLL_STD_CALL setProtocolType( int Protocol  );
DLL_EXPORT_IMPORT int   DLL_STD_CALL getProtocolType( void );

DLL_EXPORT_IMPORT void  DLL_STD_CALL OpenPort( void );
DLL_EXPORT_IMPORT void  DLL_STD_CALL OpenPortByName( char *portname );
DLL_EXPORT_IMPORT void  DLL_STD_CALL ReOpenPortByName( char *portname );
DLL_EXPORT_IMPORT void  DLL_STD_CALL ClosePort( void );
DLL_EXPORT_IMPORT void  DLL_STD_CALL Purge( void );

DLL_EXPORT_IMPORT int   DLL_STD_CALL getState( void );
DLL_EXPORT_IMPORT int   DLL_STD_CALL getLastError( void );
DLL_EXPORT_IMPORT int   DLL_STD_CALL getFiscalStatus( void );
DLL_EXPORT_IMPORT int   DLL_STD_CALL getPrinterStatus( void );
DLL_EXPORT_IMPORT int   DLL_STD_CALL getReturnCode( void );

DLL_EXPORT_IMPORT void  DLL_STD_CALL AddDataField( char *in_buffer, int in_buffer_length );
DLL_EXPORT_IMPORT void  DLL_STD_CALL SendCommand( void );
DLL_EXPORT_IMPORT void  DLL_STD_CALL SendCommandComplete( const char *command );
DLL_EXPORT_IMPORT int   DLL_STD_CALL getExtraFieldCount( void );
DLL_EXPORT_IMPORT void  DLL_STD_CALL GetExtraField( int field_number, char *output_buffer, int output_buffer_length, int *output_buffer_final_length );
DLL_EXPORT_IMPORT void  DLL_STD_CALL TakeFullAnswer( char *output_buffer, int output_buffer_length, int *output_buffer_final_length );

DLL_EXPORT_IMPORT void  DLL_STD_CALL GetSentFrame( char *output_buffer, int output_buffer_length, int *output_buffer_final_length );
DLL_EXPORT_IMPORT void  DLL_STD_CALL GetReceivedFrame( char *output_buffer, int output_buffer_length, int *output_buffer_final_length );
DLL_EXPORT_IMPORT void  DLL_STD_CALL GetTransactionFrames( char *output_buffer, int output_buffer_length, int *output_buffer_final_length, 
                                                           int include_time_stamp, int include_low_level_frames );

DLL_EXPORT_IMPORT void  DLL_STD_CALL AddRequestHeader( char *header );
DLL_EXPORT_IMPORT void  DLL_STD_CALL SendPostRequest( char *uri, char *body );
DLL_EXPORT_IMPORT void  DLL_STD_CALL SendPostRequestFromBuffer( char *uri, char *buffer, int buffer_length );
DLL_EXPORT_IMPORT void  DLL_STD_CALL SendPutRequest( char *uri, char *buffer, int buffer_length );
DLL_EXPORT_IMPORT void  DLL_STD_CALL SendDeleteRequest( char *uri, char *buffer, int buffer_length );
DLL_EXPORT_IMPORT void  DLL_STD_CALL SendGetRequest( char *uri, char *query_string );
DLL_EXPORT_IMPORT int   DLL_STD_CALL GetResponseHeadersCount( void );
DLL_EXPORT_IMPORT void  DLL_STD_CALL GetResponseHeader( int header_number, char *output_buffer, int output_buffer_length, int *output_buffer_final_length );
DLL_EXPORT_IMPORT int   DLL_STD_CALL GetHTTPStatusCode( void );
DLL_EXPORT_IMPORT void  DLL_STD_CALL GetResponse( char *output_buffer, int output_buffer_length, int *output_buffer_final_length );

DLL_EXPORT_IMPORT void  DLL_STD_CALL AddCertificate( char *certificate, char *private_key );
DLL_EXPORT_IMPORT void  DLL_STD_CALL SetSSLInsecureMode( void );

DLL_EXPORT_IMPORT int   DLL_STD_CALL GetTimeOut( void );
DLL_EXPORT_IMPORT void  DLL_STD_CALL SetTimeOut( int time_out );

#endif 

